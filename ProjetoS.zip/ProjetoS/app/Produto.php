<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Produtos extends Model
{
    protected $fillable = ['name','description','quantity','price','imagem'];
    protected $guarded = ['id','created_at','update-at'];
    protected $table = 'produtos';
}
